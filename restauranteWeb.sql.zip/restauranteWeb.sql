--
-- Banco de dados: `restauranteWeb`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `carts`
--

CREATE TABLE `carts` (
  `id` int(10) UNSIGNED NOT NULL,
  `nomeProd` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `quant` int(11) NOT NULL,
  `clienteID` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(10) UNSIGNED NOT NULL,
  `descricao` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `categorias`
--

INSERT INTO `categorias` (`id`, `descricao`) VALUES
(1, 'Pizzas'),
(2, 'Bebidas'),
(3, 'Pratos'),
(4, 'Burguers');

-- --------------------------------------------------------

--
-- Estrutura para tabela `comentarios`
--

CREATE TABLE `comentarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `Nome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `observacao` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updated_at` date NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `comentarios`
--

INSERT INTO `comentarios` (`id`, `Nome`, `email`, `observacao`, `updated_at`, `created_at`) VALUES
(1, 'Inercio', 'inercio28@gmail.com', 'blaap', '2016-04-24', '2016-04-24');

-- --------------------------------------------------------

--
-- Estrutura para tabela `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2016_04_10_113259_Produtos', 1),
('2016_04_10_115852_Categoria', 1),
('2016_04_10_145254_Reserva', 1),
('2016_04_13_194744_Cart', 1),
('2016_04_17_155836_Comentarios', 1),
('2016_04_21_174613_usuario', 2),
('2016_04_22_201917_create_users_table', 3),
('2016_04_22_203733_create_reservas_table', 4),
('2016_04_22_220420_create_reservas_table', 5),
('2016_04_24_095747_create_pedidos_table', 6),
('2016_04_24_101946_create_pedidos_table', 7),
('2016_04_24_102730_Cart', 8),
('2016_04_24_103122_Cart', 9);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(10) UNSIGNED NOT NULL,
  `clienteID` int(10) UNSIGNED NOT NULL,
  `hora` time NOT NULL,
  `observacao` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `itemsID` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nomeProduto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `preco` double NOT NULL,
  `categoria_id` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nomeProduto`, `preco`, `categoria_id`) VALUES
(1, 'Mexicana', 350, 1),
(2, '4 Estacoes', 400, 1),
(3, 'Minute Maid', 45, 2),
(4, 'Fanta', 35, 2),
(5, 'Sprite', 35, 2),
(6, 'Coca Cola', 35, 2),
(7, 'Cream Soda', 35, 2),
(8, 'Pepsi', 35, 2),
(9, 'Hamburguer completo', 170, 4),
(10, 'Hamburguer com ovo', 80, 4),
(11, 'Hamburguer duplo', 200, 4),
(12, 'X Burguer', 366, 4),
(13, 'Frango Panado', 320, 3),
(14, 'Peixe Panado', 350, 3),
(15, 'Bife a portuguesa', 420, 3),
(16, 'Bitoque', 470, 3),
(17, 'Peixe com Legumes', 390, 3),
(18, 'Bacalhau a Portuguesa', 530, 3),
(19, 'Tutto', 450, 1),
(20, 'Portuguesa', 430, 1),
(21, 'Vegetariana', 320, 1),
(22, 'Filadelfia', 510, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `reservas`
--

CREATE TABLE `reservas` (
  `id` int(10) UNSIGNED NOT NULL,
  `nomeCliente` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telefone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data` date NOT NULL,
  `hora` time NOT NULL,
  `nrAcompanhantes` int(11) NOT NULL,
  `observacao` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updated_at` date NOT NULL,
  `created_at` date NOT NULL,
  `userID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `reservas`
--

INSERT INTO `reservas` (`id`, `nomeCliente`, `email`, `telefone`, `data`, `hora`, `nrAcompanhantes`, `observacao`, `updated_at`, `created_at`, `userID`) VALUES
(10, 'Belton', 'ibelton2010@hotmail.com', '4545454545', '2016-04-13', '16:25:00', 4, 'aaah ja ta jobar', '2016-04-23', '2016-04-23', 3),
(13, 'Inercio', 'inercio28@gmail.com', '86454654', '2016-04-16', '17:54:00', 4, 'na esplanada', '2016-04-23', '2016-04-23', 2),
(15, 'Inercio', 'inercio28@gmail.com', '7575787', '2016-04-13', '16:20:00', 1, 'mesa com vista para o mar', '2016-04-23', '2016-04-23', 2);

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'Inercio', 'inercio28@gmail.com', '$2y$10$BqP9AsWsQxrjo5MLp3rFletrtBOYQTpEy3DGI.XB7DvKJx6hl2hPq', 'ErEeiYzTys75qGDvpXOhmdcZkwNfV8vEGfkOS2fWjl51KlovOSjWzapFJ8W2', '2016-04-22 20:08:52', '2016-04-24 11:34:34'),
(3, 'Belton', 'ibelton2010@hotmail.com', '$2y$10$hNn.wPOAWpmA7W2riI6YxOSsr0nfkqbZdumkzwbgbAIHXAo3Ej/sO', 'mG7hdf7LyHngLVUerI3h2c6jLyyqrVWqwbH8Hq2W6ZGNEpA1ezOaloh6Uwqx', '2016-04-23 06:43:11', '2016-04-24 11:35:24');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_clienteid_foreign` (`clienteID`);

--
-- Índices de tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedidos_clienteid_foreign` (`clienteID`),
  ADD KEY `pedidos_itemsid_foreign` (`itemsID`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reservas_userid_foreign` (`userID`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT de tabela `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_clienteid_foreign` FOREIGN KEY (`clienteID`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_clienteid_foreign` FOREIGN KEY (`clienteID`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pedidos_itemsid_foreign` FOREIGN KEY (`itemsID`) REFERENCES `carts` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `reservas_userid_foreign` FOREIGN KEY (`userID`) REFERENCES `users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
