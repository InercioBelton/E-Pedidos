--
-- Banco de dados: `restauranteWeb`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `carts`
--

CREATE TABLE `carts` (
  `id` int(10) UNSIGNED NOT NULL,
  `nomeProd` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `quant` int(11) NOT NULL,
  `pedidoID` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(10) UNSIGNED NOT NULL,
  `descricao` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `categorias`
--

INSERT INTO `categorias` (`id`, `descricao`) VALUES
(1, 'Pizzas'),
(2, 'Bebidas'),
(3, 'Pratos'),
(4, 'Burguers');

-- --------------------------------------------------------

--
-- Estrutura para tabela `comentarios`
--

CREATE TABLE `comentarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `Nome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `observacao` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updated_at` date NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `comentarios`
--

INSERT INTO `comentarios` (`id`, `Nome`, `email`, `observacao`, `updated_at`, `created_at`) VALUES
(1, 'Inercio', 'inercio28@gmail.com', 'blaap', '2016-04-24', '2016-04-24');

-- --------------------------------------------------------

--
-- Estrutura para tabela `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2016_04_10_113259_Produtos', 1),
('2016_04_10_115852_Categoria', 2),
('2016_04_17_155836_Comentarios', 2),
('2016_04_22_201917_create_users_table', 3),
('2016_04_22_220420_create_reservas_table', 3),
('2016_04_24_101946_create_pedidos_table', 3),
('2016_04_24_103122_Cart', 3),
('2016_04_25_182054_produtos_pedidos', 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(10) UNSIGNED NOT NULL,
  `clienteID` int(10) UNSIGNED NOT NULL,
  `hora` time NOT NULL,
  `observacao` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `pedidos`
--

INSERT INTO `pedidos` (`id`, `clienteID`, `hora`, `observacao`, `created_at`, `updated_at`) VALUES
(11, 4, '23:55:00', 'okkoko', '2016-04-25 17:06:17', '2016-04-25 17:06:17');

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nomeProduto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `preco` double NOT NULL,
  `categoria_id` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nomeProduto`, `preco`, `categoria_id`) VALUES
(1, 'Mexicana', 350, 1),
(2, '4 Estacoes', 400, 1),
(3, 'Minute Maid', 45, 2),
(4, 'Fanta', 35, 2),
(5, 'Sprite', 35, 2),
(6, 'Coca Cola', 35, 2),
(7, 'Cream Soda', 35, 2),
(8, 'Pepsi', 35, 2),
(9, 'Hamburguer completo', 170, 4),
(10, 'Hamburguer com ovo', 80, 4),
(11, 'Hamburguer duplo', 200, 4),
(12, 'X Burguer', 366, 4),
(13, 'Frango Panado', 320, 3),
(14, 'Peixe Panado', 350, 3),
(15, 'Bife a portuguesa', 420, 3),
(16, 'Bitoque', 470, 3),
(17, 'Peixe com Legumes', 390, 3),
(18, 'Bacalhau a Portuguesa', 530, 3),
(19, 'Tutto', 450, 1),
(20, 'Portuguesa', 430, 1),
(21, 'Vegetariana', 320, 1),
(22, 'Filadelfia', 510, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos_pedidos`
--

CREATE TABLE `produtos_pedidos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nomeProd` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `quant` int(11) NOT NULL,
  `pedidoID` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `reservas`
--

CREATE TABLE `reservas` (
  `id` int(10) UNSIGNED NOT NULL,
  `nomeCliente` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telefone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data` date NOT NULL,
  `hora` time NOT NULL,
  `nrAcompanhantes` int(11) NOT NULL,
  `observacao` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updated_at` date NOT NULL,
  `created_at` date NOT NULL,
  `userID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `reservas`
--

INSERT INTO `reservas` (`id`, `nomeCliente`, `email`, `telefone`, `data`, `hora`, `nrAcompanhantes`, `observacao`, `updated_at`, `created_at`, `userID`) VALUES
(10, 'Belton', 'ibelton2010@hotmail.com', '4545454545', '2016-04-13', '16:25:00', 4, 'aaah ja ta jobar', '2016-04-23', '2016-04-23', 3),
(13, 'Inercio', 'inercio28@gmail.com', '86454654', '2016-04-16', '17:54:00', 4, 'na esplanada', '2016-04-23', '2016-04-23', 2),
(15, 'Inercio', 'inercio28@gmail.com', '7575787', '2016-04-13', '16:20:00', 1, 'mesa com vista para o mar', '2016-04-23', '2016-04-23', 2),
(17, 'Mr. Belton', 'mrBelton@gmail.com', '845823292', '2016-04-13', '19:00:00', 1, 'Mesa proxima a saida', '2016-04-24', '2016-04-24', 4),
(18, 'Mr. Belton', 'mrBelton@gmail.com', '78478468485', '2016-04-06', '00:00:00', 2, 'nenhuma observacao', '2016-04-25', '2016-04-25', 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Fazendo dump de dados para tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'Inercio', 'inercio28@gmail.com', '$2y$10$BqP9AsWsQxrjo5MLp3rFletrtBOYQTpEy3DGI.XB7DvKJx6hl2hPq', 'YRJwY56iKn7ztWpcmfs45vtwXsHhosoqEetConU1zAxlmOFhq9VtkvPiM4MT', '2016-04-22 20:08:52', '2016-04-25 17:02:49'),
(3, 'Belton', 'ibelton2010@hotmail.com', '$2y$10$hNn.wPOAWpmA7W2riI6YxOSsr0nfkqbZdumkzwbgbAIHXAo3Ej/sO', 's4gP4IO8szTh7lUEHxMccoER9fePzmQ9wPw4BKT39xdIKuEZRuGijJk0G3iz', '2016-04-23 06:43:11', '2016-04-25 10:56:51'),
(4, 'Mr. Belton', 'mrBelton@gmail.com', '$2y$10$QWdfv0e56q8QHtSm33kTpeJyoVVul0KA5JL13Mxka9tDC5geje0QK', 'HO5DaRJu3GT6qsE0aoZ6zSnpR2Up0jHbkSIwyrjicribT5BMHY1cbq0fsUC5', '2016-04-24 15:48:19', '2016-04-25 07:20:27'),
(5, 'Teste', 'teste@gmail.com', '$2y$10$4SsXZjkv3gCTnKrS7KLwSu5oMJq8TcJn0Km0b0MNJwGK2hVBa0uMe', 'jIr0pcIswYSVf0lTW6zS2ZTsbUyMyCkXFnY5VnkOc6xO7uwgNYp2RoBjQ4Yf', '2016-04-25 06:47:56', '2016-04-25 07:05:16'),
(6, 'Andre Chirindza', 'andrechirindza@gmail.com', '$2y$10$qgYREQhZGdZFciVZjNYMtOWyhTBk5yMce.F4lyXgOygkmu4d8GdJS', 'BxjWYKf9GxaNlnaggy5ehRPqsF5Y8tdFjQRztx4CHbvD6v8e9cMgG8F1hcir', '2016-04-25 06:53:44', '2016-04-25 06:56:36'),
(7, 'rozay', 'k@gmail.com', '$2y$10$Hox3z61kAQyKC11LZI45H.n.DAail4vZ8R.gO7Mh8DiizSrPCsxvq', NULL, '2016-04-25 07:03:11', '2016-04-25 07:03:11'),
(8, 'dgfd', 'fvfdfg@fgf.b', '$2y$10$zdLm5LKXrrgRbzlj3YmL4er3iR8mzhTuLnaYj9S5X0uycPl/hzEWO', NULL, '2016-04-25 08:20:27', '2016-04-25 08:20:27'),
(9, 'Mandoza', 'admin@gmail.com', '$2y$10$Di2gh5TICjzYOUSapnI7Me.J.SYq4TNhPIsXDImqHIqlge/mI6eWS', 'l55j0IIs13LxSjw10pwxVL5LSnItIeUmS0BmcpFupf3dDG9Sw9KpUvnAmsgA', '2016-04-25 08:58:32', '2016-04-25 09:16:17');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_pedidoid_foreign` (`pedidoID`);

--
-- Índices de tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedidos_clienteid_foreign` (`clienteID`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `produtos_pedidos`
--
ALTER TABLE `produtos_pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `produtos_pedidos_pedidoid_foreign` (`pedidoID`);

--
-- Índices de tabela `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reservas_userid_foreign` (`userID`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT de tabela `produtos_pedidos`
--
ALTER TABLE `produtos_pedidos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_pedidoid_foreign` FOREIGN KEY (`pedidoID`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_clienteid_foreign` FOREIGN KEY (`clienteID`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `produtos_pedidos`
--
ALTER TABLE `produtos_pedidos`
  ADD CONSTRAINT `produtos_pedidos_pedidoid_foreign` FOREIGN KEY (`pedidoID`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `reservas_userid_foreign` FOREIGN KEY (`userID`) REFERENCES `users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
